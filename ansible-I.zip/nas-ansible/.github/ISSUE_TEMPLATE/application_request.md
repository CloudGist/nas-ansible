---
name: Application Request
about: Suggest an application to be added to Ansible-NAS
title: ''
labels: 'enhancement'
assignees: ''

---

**Application you'd like to add:**

**Link to Docker image:**

**Why you'd like this application added:**

