# Custom Applications

## Using Portainer

Ensure that you have `portainer_enabled: true` in your `group_vars/all.yml` file, and have run the playbook so that Portainer is up and running.

Hit Portainer on http://ansible_nas_host_or_ip:9000. You can now deploy an 'App Template' or head to 'Containers' and manually enter container configuration.

## Using a Custom Ansible Task

Needs to be docced