# Ombi

Homepage: [https://ombi.io/](https://ombi.io/)


Ombi is a self-hosted web application that automatically gives your shared Plex or Emby users the ability to request content by themselves! Ombi can be linked to multiple TV Show and Movie DVR tools to create a seamless end-to-end experience for your users.



## Usage

Set `ombi_enabled: true` in your `inventories/<your_inventory>/nas.yml` file.
