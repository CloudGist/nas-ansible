# Mosquitto

Homepage: [https://mosquitto.org](https://mosquitto.org)

Mosquitto is a lightweight open source MQTT message broker.

## Usage

Set `mosquitto_enabled: true` in your `inventories/<your_inventory>/nas.yml` file.

