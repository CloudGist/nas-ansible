# Serposcope

Homepage: [https://serposcope.serphacker.com/en/](https://serposcope.serphacker.com/en/)

Serposcope is a free and open-source rank tracker to monitor websites ranking in Google and improve your SEO performances

## Usage

Set `serposcope_enabled: true` in your `inventories/<your_inventory>/nas.yml` file.

The Serposcope web interface can be found at http://ansible_nas_host_or_ip:7134.
