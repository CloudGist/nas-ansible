# Firefly III

Homepage: [https://firefly-iii.org/](https://firefly-iii.org/)

Firefly III is a self-hosted financial manager. It can help you keep track of expenses, income, budgets and everything in between. It supports credit cards, shared household accounts and savings accounts. It’s pretty fancy. You should use it to save and organise money.

## Usage

Set `firefly_enabled: true` in your `inventories/<your_inventory>/nas.yml` file.

The Firefly III web interface can be found at http://ansible_nas_host_or_ip:8066.
