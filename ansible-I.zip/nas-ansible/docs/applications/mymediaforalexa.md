# My Media for Alexa

Homepage: [https://www.mymediaalexa.com/](https://www.mymediaalexa.com/)

My Media lets you stream your music collection to your Amazon Echo or Amazon Dot without having to upload all your music collection to the Cloud. This keeps your music under your control.

## Usage

Set `mymediaforalexa_enabled: true` in your `inventories/<your_inventory>/nas.yml` file.

The My Media for Alexa web interface can be found at http://ansible_nas_host_or_ip:52051.
