# get_iplayer

Homepage: [https://github.com/get-iplayer/get_iplayer](https://github.com/get-iplayer/get_iplayer)

Downloads TV and radio programmes from BBC iPlayer.

## Usage

Set `get_iplayer_enabled: true` in your `inventories/<your_inventory>/nas.yml` file.

The get_iplayer web interface can be found at http://ansible_nas_host_or_ip:8182.
