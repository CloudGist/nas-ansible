# The Lounge

Homepage: [https://thelounge.chat/](https://thelounge.chat/)

The Lounge is a self-hosted web IRC client.

## Usage

Set `thelounge_enabled: true` in your `inventories/<your_inventory>/nas.yml` file.

The Lounge web interface can be found at http://ansible_nas_host_or_ip:9000.

## Specific Configuration

The default username and password is `admin`. Change this once you've logged in!