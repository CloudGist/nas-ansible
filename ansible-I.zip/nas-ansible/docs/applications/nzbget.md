# NZBget

Homepage: [https://nzbget.net/](https://nzbget.net/)

The most efficient Usenet downloader. NZBGet is written in C++ and designed with performance in mind to achieve maximum download speed by using very little system resources.

## Usage

Set `nzbget_enabled: true` in your `inventories/<your_inventory>/nas.yml` file.

The NZBget web interface can be found at http://ansible_nas_host_or_ip:6789, the default username is `nzbget` and password `tegbzn6789`. Change this once you've logged in!
