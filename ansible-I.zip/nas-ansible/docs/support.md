# Support

Getting support for Ansible-NAS is easy!

## Gitter.im

Ansible-NAS has its own [Gitter](https://gitter.im/Ansible-NAS/Chat) chat room. `davestephens` hangs out there as well as a few existing users. Come say hi!

## GitHub Issues

Raise an [issue](https://github.com/davestephens/ansible-nas/issues), using the supplied template to provide as much information as possible.